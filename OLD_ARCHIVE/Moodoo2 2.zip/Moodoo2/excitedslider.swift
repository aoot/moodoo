//
//  excitedslider.swift
//  Moodoo2
//
//  Created by Natascha Brauchle on 4/17/18.
//  Copyright © 2018 Natascha Brauchle. All rights reserved.
//

import UIKit

class excitedslider: UISlider {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
